# Dependencies
1. Numpy
2. Pandas
3. Sklearn
4. Seaborn
5. matplotlib

# How to run?

First extract 	```solution.zip``` which contains data folder and ```Car_popularity.ipynb```, ```Car_popularity.py``` and ```train.csv```

**Run using ipynb**
Run jupyter notebook and open ```Car_popularity.ipynb```

**Using python**
Run ```Car_popularity.py``` by using pyhton

*before running these files make sure that the ```train.csv```  is in the ```data``` folder*
